<?php 
 require_once '../app/bootstrap.php';

 $init = new Core();