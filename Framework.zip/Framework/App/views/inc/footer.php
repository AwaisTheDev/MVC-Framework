<script scr="<?php echo URLROOT ?>/js/main.js">

</script>

</body>
</html>