<?php require APPROOT . '/views/inc/header.php';?>
<?php echo $data['title'] ?>
 <p>This is a Fraamework based on Model View Controller Design Pattern Originally designed by TravercyMedia and practised by Muhammad Awais</p>
<?php require APPROOT . '/views/inc/footer.php';?>