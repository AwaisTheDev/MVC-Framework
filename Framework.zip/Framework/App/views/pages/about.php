<?php require APPROOT . '/views/inc/header.php';?>
<?php echo $data['title'] ?>
<?php require APPROOT . '/views/inc/footer.php';?>