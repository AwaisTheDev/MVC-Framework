<?php

define ('DB_HOST','localhost');
define ('DB_USER','_your_user_');
define ('DB_PASS','_your_pass_');
define ('DB_NAME','_db_name');

define ('APPROOT', dirname(dirname(__FILE__)));

define ('URLROOT', '_your_url');

define ('SITENAME' , '_your_site_name');